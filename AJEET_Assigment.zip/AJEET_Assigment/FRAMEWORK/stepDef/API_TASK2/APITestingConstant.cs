﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.stepDef.api2
{
    class APITestingConstant
    {
        public static string URL = "https://reqres.in";
        public struct JsonDataForSecondAPITask
        {
            public int response_code;
            //public string error_msg;
        }
    }
}
